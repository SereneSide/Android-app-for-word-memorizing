package com.proj.wordmemorizing;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class NextActivity extends AppCompatActivity {

    private ArrayList<word> wordlist = new ArrayList<>();
    private word w;
    private ArrayList<word> wordGroup;
//    private ArrayList<word> wordList = new ArrayList<>();


    private DBHelper dbHelper;
    private SQLiteDatabase db;

    private int id;

    private Button btn1;
    private Button btn2;
    private Button btn3;

    private Button btnRemembered;
    private Button btnNotYet;

    private String topContent;
    private String downContent;
    private String topContentGroup;
    private String downContentGroup;



    private LinearLayout entry1;
    private LinearLayout entry2;

    private int wordGroupIndex=0;
    private LinearLayout wordGroupBtn;
    private LinearLayout btn;

    private TextView tv1bt1;
    private TextView tv2bt1;
    private TextView tv1bt2;
    private TextView tv2bt2;
    private TextView tv1bt3;
    private TextView tv2bt3;
    private TextView tv1Group;
    private TextView tv2Group;
    private TextView tv1;
    private TextView tv2;
    private int trans;
    private CustomAdapter adapter;
    private Button btnback;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);

        if(checkBoxSelected()){
            Toast.makeText(this,"Added successfully",Toast.LENGTH_SHORT).show();
        }
        initUI();
    }

    private void initUI() {


        wordGroupBtn=(LinearLayout) findViewById(R.id.wordGroupBtn);
        btn=(LinearLayout) findViewById(R.id.master_level);
        btn1=(Button)findViewById(R.id.btn_familar);
        btn2=(Button)findViewById(R.id.btn_no_idea);
        btn3=(Button)findViewById(R.id.btn_aware);
        btnback = (Button) findViewById(R.id.btn_back);

        entry1 = (LinearLayout) findViewById(R.id.store_database_word);
        entry2 = (LinearLayout) findViewById(R.id.store_database_meaning);

        dbHelper = new DBHelper(this);
        db = dbHelper.getWritableDatabase();
        Cursor cursor=db.rawQuery("select * from wordtable",null);
        while (cursor.moveToNext()) {
            id = (cursor.getInt(cursor.getColumnIndex("id")));
            String en_word = cursor.getString(cursor.getColumnIndex("en_word"));
            String meaning = cursor.getString(cursor.getColumnIndex("meaning"));
            w = new word(id, en_word, meaning);
            wordlist.add(w);//存了所有的单词
        }
        adapter = new CustomAdapter(this,wordlist);//返回被选择的checkbox的值
//        for(int i=0;i<adapter.wordArrayList.size();i++){
//            if(adapter.wordArrayList.get(i).getSelected()){
//                wordlist.add(adapter.wordArrayList.get(i));
////            }
//
//        }

        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });



        wordGroup = new ArrayList<word>(3);
        topContent = new String();
        downContent = new String();
        id=0;

        topContent=wordlist.get(id).toStringWord();
        downContent = wordlist.get(id).toStringMeaning();

        wordGroup.add(wordlist.get(0));


        tv1 = new TextView(this);
        tv1.setGravity(Gravity.CENTER);
        tv2 = new TextView(this);
        tv2.setGravity(Gravity.CENTER);

        tv1.setText(topContent);
        tv2.setText(downContent);
        tv1.setTextSize(40);
        tv2.setTextSize(28);
        entry1.addView(tv1);
        entry2.addView(tv2);

        tv1bt1 = new TextView(this);
        tv2bt1 = new TextView(this);
        tv1bt1.setGravity(Gravity.CENTER);
        tv2bt1.setGravity(Gravity.CENTER);

        tv1bt2 = new TextView(this);
        tv2bt2 = new TextView(this);
        tv1bt2.setGravity(Gravity.CENTER);
        tv2bt2.setGravity(Gravity.CENTER);

        tv1bt3 = new TextView(this);
        tv2bt3 = new TextView(this);
        tv1bt3.setGravity(Gravity.CENTER);
        tv2bt3.setGravity(Gravity.CENTER);

        tv1Group = new TextView(this);
        tv2Group = new TextView(this);
        tv1Group.setGravity(Gravity.CENTER);
        tv2Group.setGravity(Gravity.CENTER);

        btn1 = (Button) findViewById(R.id.btn_familar);
        btn2 = (Button) findViewById(R.id.btn_no_idea);
        btn3 = (Button) findViewById(R.id.btn_aware);
        btnRemembered=findViewById(R.id.wordGroupBtn1);
        btnNotYet=findViewById(R.id.wordGroupBtn2);

        threeButtonMethod();


    }

    public void threeButtonMethod(){

        wordGroupBtn.setVisibility(View.INVISIBLE);
        btn.setVisibility(View.VISIBLE);

        btn1.setOnClickListener(new View.OnClickListener() {
            //familar
            @Override
            public void onClick(View v) {

                //Toast.makeText(NextActivity.this,"you have clicked on Button1",Toast.LENGTH_SHORT).show();
                if ((getChildren(entry1)) && (getChildren(entry2))){
                    entry1.removeAllViews();
                    entry2.removeAllViews();
                }
                if(wordGroup.isEmpty()){
                    //print
                    //Toast.makeText(NextActivity.this,"wordGroup空集!!!!不能remove",Toast.LENGTH_SHORT).show();

                }else{
                    wordGroup.remove(wordlist.get(id));//去掉熟悉的
                    //Toast.makeText(NextActivity.this,"点击第一个键，词被去掉了",Toast.LENGTH_SHORT).show();
                }

                if(id<wordlist.size()-1 && id>=0 && wordGroup.size()<3){
                    id++;
//                        if(wordGroup.size()<3 && notExistInWordGroup(personList.get(id))){
//                            wordGroup.add(personList.get(id));//添加下一个
//                        }
                    topContent = wordlist.get(id).toStringWord();
                    downContent = wordlist.get(id).toStringMeaning();
                }else{
                    //Toast.makeText(NextActivity.this,"到底了！！！！！",Toast.LENGTH_SHORT).show();
                }

                tv1bt1.setText(topContent);
                tv2bt1.setText(downContent);
                tv1bt1.setTextSize(40);
                tv2bt1.setTextSize(28);
                entry1.addView(tv1bt1);
                entry2.addView(tv2bt1);
                //先销毁tv1和tv2再addView


                //wordGroupisFull
                if(wordGroup.size()==3){
                    twoButtonMethod();
                }
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            //no idea//就是把这个单词加入三词组中
            @Override
            public void onClick(View v) {
                Toast.makeText(NextActivity.this,"Added to review list",Toast.LENGTH_SHORT).show();

                //Toast.makeText(MainActivity.this,"no idea单词已经加入（存在/不存在）",Toast.LENGTH_SHORT).show();


                if(id<wordlist.size() && id>=0 &&(wordGroup.size()<3) && notExistInWordGroup(wordlist.get(id))){ //并且没有在wordGroup出现过
                    wordGroup.add(wordlist.get(id));//添加下一个
                    //Toast.makeText(MainActivity.this,"no idea单词已加入group，原来不存在",Toast.LENGTH_SHORT).show();
                }


                if ((getChildren(entry1)) && (getChildren(entry2))){
                    entry1.removeAllViews();
                    entry2.removeAllViews();
                    //Toast.makeText(MainActivity.this,"BT2，Views被去掉了",Toast.LENGTH_SHORT).show();
                }

                if(id==0){
                    id++;
                    //无事发生
                    //index=0 已经在wodList中
                }else{
                    if(id<wordlist.size() && id>=0 ){
                        if(id<wordlist.size()-1){
                            id++;
                        }

                        topContent = wordlist.get(id).toStringWord();
                        downContent = wordlist.get(id).toStringMeaning();
//                            if((wordGroup.size()<3) && notExistInWordGroup(personList.get(id))){ //并且没有在wordGroup出现过
//                                wordGroup.add(personList.get(id));//添加下一个
//                                Toast.makeText(MainActivity.this,"BT2单词被添加了",Toast.LENGTH_SHORT).show();
//                            }
                    }else{
                        //Toast.makeText(NextActivity.this,"到底了bt2！！！！！",Toast.LENGTH_SHORT).show();
                    }
                }

                topContent = wordlist.get(id).toStringWord();
                downContent = wordlist.get(id).toStringMeaning();

                tv1bt2.setText(topContent);
                tv2bt2.setText(downContent);
                tv1bt2.setTextSize(40);
                tv2bt2.setTextSize(28);
                entry1.addView(tv1bt2);
                entry2.addView(tv2bt2);

                if(wordGroup.size()==3){

                    twoButtonMethod();

                }
            }
        });

        btn3.setOnClickListener(new View.OnClickListener(){
            //aware
            @Override
            public void onClick(View v) {

                if(id<wordlist.size() && id>=0 && wordGroup.size()<3 && notExistInWordGroup(wordlist.get(id))){
                    wordGroup.add(wordlist.get(id));//添加下一个
                    Toast.makeText(NextActivity.this,"Added to review list",Toast.LENGTH_SHORT).show();
                }

                //Toast.makeText(NextActivity.this,"you have clicked Button3",Toast.LENGTH_SHORT).show();
                if ((getChildren(entry1)) && (getChildren(entry2))){
                    entry1.removeAllViews();
                    entry2.removeAllViews();
                }

                if(id==0){
                    id++;
                    //无事发生
                    //index=0 已经在wodList中
                }else{
                    if(id<wordlist.size() && id>=0 ){
                        if(id<wordlist.size()-1){
                            id++;
                        }

                        topContent = wordlist.get(id).toStringWord();
                        downContent = wordlist.get(id).toStringMeaning();
//                            if(wordGroup.size()<3 && notExistInWordGroup(personList.get(id))){
//                                wordGroup.add(personList.get(id));//添加下一个
//                                Toast.makeText(MainActivity.this,"BT3单词被添加了",Toast.LENGTH_SHORT).show();
//                            }
                    }else{
                        //Toast.makeText(NextActivity.this,"到底了bt3！！！！！",Toast.LENGTH_SHORT).show();
                    }
                }

                topContent = wordlist.get(id).toStringWord();
                downContent = wordlist.get(id).toStringMeaning();

                tv1bt3.setText(topContent);
                tv2bt3.setText(downContent);
                tv1bt3.setTextSize(40);
                tv2bt3.setTextSize(28);
                entry1.addView(tv1bt3);
                entry2.addView(tv2bt3);

                if(wordGroup.size()==3){
                    twoButtonMethod();
                }
            }
        });
    }

    public void twoButtonMethod(){

        btn.setVisibility(View.INVISIBLE);
        wordGroupBtn.setVisibility(View.VISIBLE);

        if ((getChildren(entry1)) && (getChildren(entry2))){
            entry1.removeAllViews();
            entry2.removeAllViews();
        }

        topContentGroup = wordGroup.get(0).toStringWord();
        downContentGroup = wordGroup.get(0).toStringMeaning();

        tv1Group.setText(topContentGroup);
        tv1Group.setTextSize(40);

        tv2Group.setText(downContentGroup);
        tv2Group.setTextSize(28);

        entry1.addView(tv1Group);
        entry2.addView(tv2Group);

        btnRemembered.setOnClickListener(new View.OnClickListener() {
            //大概是可以这样写的，如果不行，新建三个按钮FrameLayout覆盖原来三个？？
            @Override
            public void onClick(View v) {
                //familar
                //Toast.makeText(NextActivity.this,"you have clicked on Remembered",Toast.LENGTH_SHORT).show();

                if ((getChildren(entry1)) && (getChildren(entry2))){
                    entry1.removeAllViews();
                    entry2.removeAllViews();
                }
                if(wordGroup.isEmpty()){
                    //print
                    //Toast.makeText(NextActivity.this,"wordGroup空集!!!!不能remove",Toast.LENGTH_SHORT).show();
                }else{
                    wordGroup.remove(wordGroup.get(wordGroupIndex));//现在index是0；0,1,2去掉0，变成0,1
                }

                if(wordGroupIndex<wordGroup.size() && wordGroupIndex>=0){
                    wordGroupIndex--;//现在应当是显示第二个数，即1，但是他现在变成了0
                    wordGroupIndex++;

                }else{
                    Toast.makeText(NextActivity.this,"wordGroup到底了remembered！！！！！",Toast.LENGTH_SHORT).show();
                }

                if(wordGroup.size()!=0){
                    topContentGroup = wordGroup.get(wordGroupIndex).toStringWord();
                    downContentGroup = wordGroup.get(wordGroupIndex).toStringMeaning();

                    //两个TextView
                    tv1Group.setText(topContentGroup);
                    tv2Group.setText(downContentGroup);
                    tv1Group.setTextSize(40);
                    tv2Group.setTextSize(28);
                    //两个LinearLayout
                    entry1.addView(tv1Group);
                    entry2.addView(tv2Group);


                }else {
                    //Toast.makeText(NextActivity.this,"wordGroup空了！！！！！",Toast.LENGTH_SHORT).show();
                    //id++;
                    topContent = wordlist.get(id).toStringWord();
                    downContent = wordlist.get(id).toStringMeaning();

                    tv1.setText(topContent);
                    tv2.setText(downContent);
                    tv1.setTextSize(40);
                    tv2.setTextSize(28);
                    entry1.addView(tv1);
                    entry2.addView(tv2);
                    threeButtonMethod();
                }


            }
        });

        btnNotYet.setOnClickListener(new View.OnClickListener() {//第一个not yet，跳到stayInGroup
            @Override

            public void onClick(View v) {
                //Toast.makeText(NextActivity.this,"you have clicked on NotYet",Toast.LENGTH_SHORT).show();

                if(wordGroup.size()!=0){

                    //不能跳出group背诵循环
                    stayInGroup(wordGroupIndex);

                }else {//size==0
                    //Toast.makeText(NextActivity.this,"wordGroup空了！！！！！",Toast.LENGTH_SHORT).show();
                    //id++;
                    topContent = wordlist.get(id).toStringWord();
                    downContent = wordlist.get(id).toStringMeaning();

                    tv1.setText(topContent);
                    tv2.setText(downContent);
                    tv1.setTextSize(40);
                    tv2.setTextSize(28);
                    entry1.addView(tv1);
                    entry2.addView(tv2);
                    threeButtonMethod();
                }
            }
        });

    }

    public void stayInGroup(int wordGroupIndex) {
        //stayinGroup先展示下一个单词 然后是两个按钮的再选择
        if ((getChildren(entry1)) && (getChildren(entry2))){
            entry1.removeAllViews();
            entry2.removeAllViews();
        }

        if(wordGroup.size()!=0 && wordGroupIndex==2){//防止出现“到底了wordGroup notyet！！！！！”
            wordGroupIndex=0;
            //Toast.makeText(NextActivity.this,"将wordGroupIndex重置为了0",Toast.LENGTH_SHORT).show();
            //设置index为0之后，先显示index0时的内容

            //两个String
            topContentGroup = wordGroup.get(0).toStringWord();
            downContentGroup = wordGroup.get(0).toStringMeaning();


            //两个TextView
            tv1Group.setText(topContentGroup);
            tv2Group.setText(downContentGroup);
            tv1Group.setTextSize(40);
            tv2Group.setTextSize(28);

            //两个LinearLayout
            entry1.addView(tv1Group);
            entry2.addView(tv2Group);

            //值已经改变，但是不显示页面
        }

        if(wordGroupIndex<wordGroup.size() && wordGroupIndex>=0 ){
            wordGroupIndex++;
        }else{
            //Toast.makeText(NextActivity.this,"到底了wordGroup notyet！！！！！",Toast.LENGTH_SHORT).show();
        }

        if ((getChildren(entry1)) && (getChildren(entry2))){
            entry1.removeAllViews();
            entry2.removeAllViews();
        }

        if(wordGroupIndex<wordGroup.size() && wordGroupIndex>=0 ){
            //两个String
            topContentGroup = wordGroup.get(wordGroupIndex).toStringWord();//改了啊啊啊啊啊啊啊啊啊啊啊啊！！！！！！！！！！！！！
            downContentGroup = wordGroup.get(wordGroupIndex).toStringMeaning();

            //两个TextView
            tv1Group.setText(topContentGroup);
            tv2Group.setText(downContentGroup);
            tv1Group.setTextSize(40);
            tv2Group.setTextSize(28);
            //两个LinearLayout
            entry1.addView(tv1Group);
            entry2.addView(tv2Group);
        }else{
            //Toast.makeText(NextActivity.this,"没了",Toast.LENGTH_SHORT).show();
        }



        trans = wordGroupIndex;

        btnNotYet.setOnClickListener(new View.OnClickListener() {//第二个not yet
            @Override
            public void onClick(View v) {
                //Toast.makeText(NextActivity.this,"you have clicked on NotYet",Toast.LENGTH_SHORT).show();
                if(wordGroup.size()!=0){

                    //不能跳出group背诵循环
                    stayInGroup(trans);



                }else {//size==0
                    //Toast.makeText(NextActivity.this,"wordGroup空了！！！！！",Toast.LENGTH_SHORT).show();
                    //id++;
                    topContent = wordlist.get(id).toStringWord();
                    downContent = wordlist.get(id).toStringMeaning();

                    tv1.setText(topContent);
                    tv2.setText(downContent);
                    tv1.setTextSize(40);
                    tv2.setTextSize(28);
                    entry1.addView(tv1);
                    entry2.addView(tv2);
                    threeButtonMethod();
                }

            }
        });

        btnRemembered.setOnClickListener(new View.OnClickListener() {//ButtonClick
            @Override
            public void onClick(View v) {
                //Toast.makeText(NextActivity.this,"you have clicked on Remembered",Toast.LENGTH_SHORT).show();

                if ((getChildren(entry1)) && (getChildren(entry2))){
                    entry1.removeAllViews();
                    entry2.removeAllViews();
                }
                if(wordGroup.isEmpty()){
                    //print
                    //Toast.makeText(NextActivity.this,"wordGroup空集!!!!不能remove",Toast.LENGTH_SHORT).show();
                }else{
                    wordGroup.remove(wordGroup.get(trans));//现在index是0；0,1,2去掉0，变成0,1
                }

                if(trans <wordGroup.size() && trans >=0){
//                    trans--;//现在应当是显示第二个数，即1，但是他现在变成了0
//                    trans++;

                }else{
                    //Toast.makeText(NextActivity.this,"wordGroup到底了remembered！！！！！",Toast.LENGTH_SHORT).show();
                }

                if(wordGroup.size()!=0 && trans<wordGroup.size() &&trans >=0){
                    topContentGroup = wordGroup.get(trans).toStringWord();
                    downContentGroup = wordGroup.get(trans).toStringMeaning();

                    //两个TextView
                    tv1Group.setText(topContentGroup);
                    tv2Group.setText(downContentGroup);
                    tv1Group.setTextSize(40);
                    tv2Group.setTextSize(28);
                    //两个LinearLayout
                    entry1.addView(tv1Group);
                    entry2.addView(tv2Group);

                }else {
                    //Toast.makeText(NextActivity.this,"wordGroup空了！！！！！",Toast.LENGTH_SHORT).show();
                    //id++;
                    topContent = wordlist.get(id).toStringWord();
                    downContent = wordlist.get(id).toStringMeaning();

                    tv1.setText(topContent);
                    tv2.setText(downContent);
                    tv1.setTextSize(40);
                    tv2.setTextSize(28);
                    entry1.addView(tv1);
                    entry2.addView(tv2);
                    threeButtonMethod();
                }
            }
        });




    }
    public boolean notExistInWordGroup(word w) {
        for(int i=0;i<=wordGroup.size()-1;i++){
            if(w.equals(wordGroup.get(i))){
                return false;
            }
        }
        return true;
    }

    public boolean wordGroupIsFull(){
        //每次点击鼠标前先检查wordGroup是否为空，如果不空那就先背这个组里面的
        if(wordGroup.size() ==3 ){
            return true;
        }
        return false;

    }

    //背组里的单词
    public void reciteGroup(){
        if ((getChildren(entry1)) && (getChildren(entry2))){
            entry1.removeAllViews();
            entry2.removeAllViews();
        }
        TextView tv1Group = new TextView(NextActivity.this);
        TextView tv2Group = new TextView(NextActivity.this);

        String topContentGroup = wordGroup.get(0).toStringWord();
        String downContentGroup = wordGroup.get(0).toStringMeaning();

        tv1Group.setText(topContentGroup);
        tv1Group.setTextSize(40);

        tv2Group.setText(downContentGroup);
        tv2Group.setTextSize(28);

        entry1.addView(tv1Group);
        entry2.addView(tv2Group);
    }

    public boolean getChildren(LinearLayout parent) {
        int countChildren=0;
        View v;
        for (countChildren=0;countChildren<10;countChildren++){
            v =parent.getChildAt(countChildren);
            if(v!=null){
                return true;
            }
        }
        return false;    }

    public boolean notAlreadyExist(word w){
        for(int i =0;i<=2;i++){//wordGroup里不存在因为点击了no idea所以要重复存储的单词
            if(wordGroup.get(i)!=w){
                return true;
            }
        }
        return false;
    }



    boolean checkBoxSelected(){
        int countSelected=0;
        for (int i = 0; i < CustomAdapter.wordArrayList.size(); i++){
            if(CustomAdapter.wordArrayList.get(i).getSelected()) {
                countSelected++;
            }
        }
        if(countSelected>0){
            return true;
        }else {
            return false;
        }
    }

}
