package com.proj.wordmemorizing;
//一个.xml文件和一个activity.java文件，，前者是创建页面布局，后者是实例化这个布局以及布局的内容
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements fragment_review.OnFragmentInteractionListener,
        fragment_wordlist.OnFragmentInteractionListener,
        fragment_settings.OnFragmentInteractionListener{

    private TextView labelText;
    private BottomNavigationView navigation;


    Fragment fragment1 = new fragment_review();
    Fragment fragment2 = new fragment_wordlist();
    Fragment fragment3 = new fragment_settings();
    Fragment fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);//1. 显示activity_main.xml中的所有页面元素
        int idget = getIntent().getIntExtra("idid", 0);

        if(idget==100){
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.frame_container,new fragment_wordlist())
                    .addToBackStack(null)
                    .commit();
        }

        initUI();//2. 用initUI()初始化界面元素的值
    }
    private void initUI() {
        //3. 即 setContentView中的所有元素会被初始化为某个初值
//        labelText = findViewById(R.id.labelText);
//        labelText.setText(R.string.title_review);
        fragment=fragment1;
        loadFragment(fragment1);
        navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.navigation_review:
//                        labelText.setText(R.string.title_review);
                        switchToNewFragment(R.id.frame_container, fragment1);
                    return true;
                    case R.id.navigation_wordlist:
//                        labelText.setText(R.string.title_wordlist);
                        switchToNewFragment(R.id.frame_container, fragment2);
                    return true;
                    case R.id.navigation_settings:
//                        labelText.setText(R.string.title_settings);
                        switchToNewFragment(R.id.frame_container, fragment3);
                    return true;
                }
            return false;
            }
        });
    }

    private void loadFragment(Fragment fragment) {
        // load fragment 处理fragment
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        //replace这个方法，可清除所有已经添加到容器View里面的Fragment，然后再添加我们传入的Fragment
        transaction.replace(R.id.frame_container, fragment).commit();
        //当我们不需要fragment会退到上一个界面或者管理的fragment过多而不想保留BackStackRecord记录过度使用资源时，就可以加入回退栈
        //transaction.addToBackStack(null);
    }

    private void switchToNewFragment(int integer, Fragment f) {
        if (fragment !=f) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            if (!f.isAdded()) { // 判断是否被add过
                // 隐藏当前的fragment，将 下一个fragment 添加进去
                transaction.hide(fragment).add(integer, f).commit();

            } else {
                // 隐藏当前的fragment，显示下一个fragment
                transaction.hide(fragment).show(f).commit();
            }
            fragment = f;
        }

    }


    @Override
    public void onFragmentInteraction(Uri uri) {
        //LEAVE IT EMPTY
        //解决点击不同FRAGMENT闪退的问题
        //class implements 3个fragments监听
    }
}
