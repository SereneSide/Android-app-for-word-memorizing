package com.proj.wordmemorizing;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class fragment_settings extends Fragment {


    private View rootView;
    Button btnSignIn,btnSignUp;
    LoginDataBaseAdapter loginDataBaseAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_fragment_settings, container, false);
        initUI();
        return rootView;
    }

    private void initUI() {
        // create a instance of SQLite Database
        loginDataBaseAdapter=new LoginDataBaseAdapter(getContext());
        loginDataBaseAdapter=loginDataBaseAdapter.open();

// Get The Refference Of Buttons
        btnSignIn=(Button)rootView.findViewById(R.id.buttonSignIN);
        btnSignUp=(Button)rootView.findViewById(R.id.buttonSignUP);

        // Set OnClick Listener on SignUp button
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
// TODO Auto-generated method stub

/// Create Intent for SignUpActivity abd Start The Activity
                Intent intentSignUP=new Intent(getContext(),SignUPActivity.class);
                startActivity(intentSignUP);
            }
        });

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog = new Dialog(getActivity());
                dialog.setContentView(R.layout.login);
                dialog.setTitle("Login");

// get the Refferences of views
                final EditText editTextUserName=(EditText)dialog.findViewById(R.id.editTextUserNameToLogin);
                final EditText editTextPassword=(EditText)dialog.findViewById(R.id.editTextPasswordToLogin);

                Button btnSignIn=(Button)dialog.findViewById(R.id.buttonSignIn);

// Set On ClickListener
                btnSignIn.setOnClickListener(new View.OnClickListener() {

                    public void onClick(View v) {
// get The User name and Password
                        String userName=editTextUserName.getText().toString();
                        String password=editTextPassword.getText().toString();

// fetch the Password form database for respective user name
                        String storedPassword=loginDataBaseAdapter.getSinlgeEntry(userName);

// check if the Stored password matches with Password entered by user
                        if(password.equals(storedPassword)){
                            Toast.makeText(getActivity(), "Congrats: Login Successfully", Toast.LENGTH_LONG).show();

                            dialog.dismiss();
                            Intent intent = new Intent(getActivity(),welact.class);
                            startActivity(intent);
                        }
                        else{
                            Toast.makeText(getActivity(), "User Name or Password does not match", Toast.LENGTH_LONG).show();
                        }
                    }
                });

                dialog.show();
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
// Close The Database
        loginDataBaseAdapter.close();
    }

    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }
}
