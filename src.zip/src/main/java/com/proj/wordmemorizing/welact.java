package com.proj.wordmemorizing;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class welact extends AppCompatActivity {

    private TextView tv;
    private LinearLayout wel;
    private TextView tvwel2;

    Fragment fragment;
    private Button btnback;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);

        tv = (TextView) findViewById(R.id.tv_welcome);
        wel = (LinearLayout)findViewById(R.id.wel);
        tvwel2 = (TextView) findViewById(R.id.tvwel2);
        btnback =(Button) findViewById(R.id.goback);

        tv.setText("Welcome to WordMemorizing");
        tv.setTextSize(30);
        tvwel2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/html");
                intent.putExtra(Intent.EXTRA_EMAIL, "emailaddress@emailaddress.com");
                intent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
                intent.putExtra(Intent.EXTRA_TEXT, "I'm email body.");

                startActivity(Intent.createChooser(intent, "Send Email"));
            }
        });

        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(welact.this,"welcome page",Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(welact.this, MainActivity.class);
                intent.putExtra("idid",100);
                startActivity(intent);

            }
        });


    }

    private void switchToNewFragment(int integer, Fragment f) {
        if (fragment !=f) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            if (!f.isAdded()) { // 判断是否被add过
                // 隐藏当前的fragment，将 下一个fragment 添加进去
                transaction.hide(fragment).add(integer, f).commit();

            } else {
                // 隐藏当前的fragment，显示下一个fragment
                transaction.hide(fragment).show(f).commit();
            }
            fragment = f;
        }
    }
}
