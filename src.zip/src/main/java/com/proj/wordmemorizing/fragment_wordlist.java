package com.proj.wordmemorizing;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class fragment_wordlist extends Fragment {

    private View rootView;
    private ListView lv;
    private ArrayList<word> wordArrayList;
    private CustomAdapter customAdapter;
    private Button btnselect, btndeselect, btnnext;
    private ArrayList<word> wordlist;
    private SQLiteDatabase db;
    private DBHelper dbHelper;
    private int id;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView =inflater.inflate(R.layout.fragment_fragment_wordlist, container, false);
        initUI();
        return rootView;

    }

    private void initUI() {

        wordlist = new ArrayList<word>();
        dbHelper = new DBHelper(getActivity());
        db = dbHelper.getWritableDatabase();
        Cursor cursor= db.rawQuery("select * from wordtable",null);
        while (cursor.moveToNext()) {

            id = (cursor.getInt(cursor.getColumnIndex("id")));
            String en_word = cursor.getString(cursor.getColumnIndex("en_word"));
            String meaning = cursor.getString(cursor.getColumnIndex("meaning"));
            word w = new word(id, en_word, meaning);
            wordlist.add(w);
        }

        lv = (ListView) rootView.findViewById(R.id.lv);
        btnselect = (Button) rootView.findViewById(R.id.select);
        btndeselect = (Button) rootView.findViewById(R.id.deselect);
        btnnext = (Button) rootView.findViewById(R.id.next);

        wordArrayList = getModel(false);
        customAdapter = new CustomAdapter(getContext(),wordArrayList);
        lv.setAdapter(customAdapter);

        btnselect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wordArrayList = getModel(true);
                customAdapter = new CustomAdapter(getContext(),wordArrayList);
                lv.setAdapter(customAdapter);
            }
        });
        btndeselect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wordArrayList = getModel(false);
                customAdapter = new CustomAdapter(getContext(),wordArrayList);
                lv.setAdapter(customAdapter);
            }
        });
        btnnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),NextActivity.class);
                startActivity(intent);
            }
        });


    }

    private ArrayList<word> getModel(boolean isSelect){
        int i=0;
        ArrayList<word> list = new ArrayList<>();
        for( i = 0; i < wordlist.size(); i++){
            word wordmodel = new word(0,"","");
            wordmodel.setSelected(isSelect);
            wordmodel.setEn_word(wordlist.get(i).getEn_word());
            list.add(wordmodel);
        }
        return list;
    }


    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }
}
