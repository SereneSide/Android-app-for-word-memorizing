//package com.proj.wordmemorizing;
//
//import android.content.Context;
//import android.database.sqlite.SQLiteDatabase;
//import android.database.sqlite.SQLiteOpenHelper;
//
////生成数据库、更新数据库
////构造数据库对象
//public class DBHelper extends SQLiteOpenHelper {
//
//    final String CREATE_WORD_TABLE = "CREATE TABLE word (" +
//            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
//            "word TEXT,"+
//            "meaning TEXT)";
//
//    final String UPDATE_TABLE ="ALTER TABLE word ADD COLUMN other TEXT";
//
//    public DBHelper(Context context) {
//        super(context, "databaseName.db", null, 1);
//    }
//
//    @Override
//    public void onCreate(SQLiteDatabase db) {
//        db.execSQL(CREATE_WORD_TABLE);
//
//    }
//
//    @Override
//    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//        db.execSQL(UPDATE_TABLE);
//
//    }
//}
package com.proj.wordmemorizing;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {
    String CREATE_TABLE="CREATE TABLE wordtable(id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "en_word CHAR," +
            "meaning CHAR)";
    String INSERT_DATA="INSERT INTO wordtable (id,en_word,meaning)";
    String VALUES1 ="VALUES(1, 'abandon','n. 狂热；放任 vt.遗弃')";
    String VALUES2 ="VALUES(2, 'accumulate ',' vt. 积攒 vi. 累积   ' )";
    String VALUES3 ="VALUES(3, ' adverse ','adj. 不利的；相反的   ' )";
    String VALUES4 ="VALUES(4, 'assemble  ',' vt. 集合 vi.聚集  ' )";
    String VALUES5 ="VALUES(5, ' barter ',' n.贸易 vt. 以…作为交换；  ' )";
    String VALUES6 ="VALUES(6, ' boulder ',' n. 卵石，大圆石  ' )";
    String VALUES7 ="VALUES(7,   'bulb',' n. 电灯泡；vi. 生球茎；  ' )";
    String VALUES8 ="VALUES(8, ' casualty   ','  n. 意外事故；伤亡人员 ' )";
    String VALUES9 ="VALUES(9, ' civilian ','  adj. 民用的；n. 平民 ' )";
    String VALUES10 ="VALUES(10, ' conceive ','  vt. 怀孕；构思 ' )";
    String VALUES11 ="VALUES(11, 'consecutive  ',' adj. 连贯的；连续不断的  ' )";
    String VALUES12 ="VALUES(12, 'curriculum  ','n.课程   ' )";
    String VALUES13 ="VALUES(13, 'divert  ',' vt. 转移；使…欢娱  ' )";
    String VALUES14 ="VALUES(14, ' emanate   ','  vt.放射 vi. 发出 ' )";
    String VALUES15 ="VALUES(15, 'entail  ','vt. 必需 n. 限定继承  ' )";
    String VALUES16 ="VALUES(16, ' etch ','  vt. 蚀刻 n. 刻蚀 ' )";
    String VALUES17 ="VALUES(17, 'forage  ',' n. 饲料 vi. 搜寻  ' )";
    String VALUES18 ="VALUES(18, ' flap ','n. 拍打 vi. 拍动   ' )";
    String VALUES19 ="VALUES(19, 'genre  ','n. 类型 adj. 风俗画的   ' )";
    String VALUES20 ="VALUES(20, ' gradient   ',' n. 梯度 adj. 倾斜的   ' )";
    String VALUES21 ="VALUES(21, 'herb  ',' n. 香草，药草  ' )";
    String VALUES22 ="VALUES(22, ' incentive ',' n. 动机 adj. 激励的  ' )";
    String VALUES23 ="VALUES(23, 'insult  ','vt. 侮辱 n.侮辱   ' )";
    String VALUES24 ="VALUES(24, ' invade ',' vt. 侵略;侵袭  ' )";
    String VALUES25 ="VALUES(25, 'lathe  ',' vt. 用车床加工 n. 车床  ' )";
    String VALUES26 ="VALUES(26, ' log   ','n. 记录；航行日志    ' )";
    String VALUES27 ="VALUES(27, 'magnify  ',' vt. 放大；赞美  ' )";
    String VALUES28 ="VALUES(28, ' meteorite ','n. 陨星；流星   ' )";
    String VALUES29 ="VALUES(29, 'mission  ',' n. 使命 vt. 派遣 ' )";
    String VALUES30 ="VALUES(30, 'mosaic  ','adj. 嵌花式的 n. 马赛克  ' )";
    String VALUES31 ="VALUES(31, ' nebula ',' n. 星云；角膜云翳  ' )";
    String VALUES32 ="VALUES(32, 'nostalgia    ','n. 乡愁；怀旧之情    ' )";
    String VALUES33 ="VALUES(33, ' orchid ','n. 兰花 adj. 淡紫色的  ' )";
    String VALUES34 ="VALUES(34, 'overturn  ',' vt. 推翻；倾覆  ' )";
    String VALUES35 ="VALUES(35, ' photosynthesis ','n. [化]光合作用   ' )";
    String VALUES36 ="VALUES(36, ' plateau ','  n. 高原；稳定水平 ' )";
    String VALUES37 ="VALUES(37, 'portable  ','adj. 手提的，便携式的   ' )";
    String VALUES38 ="VALUES(38, 'precipitate    ',' n. 沉淀物 vt. 使沉淀   ' )";
    String VALUES39 ="VALUES(39, ' provoke ',' vt. 驱使；激怒  ' )";
    String VALUES40 ="VALUES(40, ' quartz ','n. 石英、水晶   ' )";
    String VALUES41 ="VALUES(41, 'regenerate  ','vt. 使再生；革新   ' )";
    String VALUES42 ="VALUES(42, 'runof  ',' n. 径流；决赛  ' )";
    String VALUES43 ="VALUES(43, 'scavenger  ',' n. 食腐动物；清道夫  ' )";
    String VALUES44 ="VALUES(44, 'secrete    ','vt. 藏匿；私下侵吞    ' )";
    String VALUES45 ="VALUES(45, ' shrink ',' vi. 收缩；畏缩  ' )";
    String VALUES46 ="VALUES(46, ' slide ',' n. 滑动；幻灯片  ' )";
    String VALUES47 ="VALUES(47, ' spiky ','adj.尖刻的；易怒的   ' )";
    String VALUES48 ="VALUES(48, 'squeeze  ','vt. 挤；紧握   ' )";
    String VALUES49 ="VALUES(49, 'strain  ',' n. 张力；拉紧  ' )";
    String VALUES50 ="VALUES(50, 'submerge    ',' vt. 淹没   ' )";
    String VALUES51 ="VALUES(51, ' sustain ',' vt. 维持；支撑  ' )";
    String VALUES52 ="VALUES(52, 'summit  ',' adj. 最高级的；政府首脑的  ' )";
    String VALUES53 ="VALUES(53, ' transparent ','adj. 透明的；显然的   ' )";
    String VALUES54 ="VALUES(54, 'utility  ','n. 实用；效用   ' )";
    String VALUES55 ="VALUES(55, 'venture  ','vi. 冒险；投机   ' )";
    String VALUES56 ="VALUES(56, ' withdraw   ','vt. 撤退；收回    ' )";
    String VALUES57 ="VALUES(57, 'abhor  ','vt. 痛恨，憎恶   ' )";
    String VALUES58 ="VALUES(58, 'accuse  ','vt. 控告，指控   ' )";
    String VALUES59 ="VALUES(59, 'ambition  ','n. 野心，雄心   ' )";
    String VALUES60 ="VALUES(60, 'approximately  ','adv. 大约，近似地   ' )";
    String VALUES61 ="VALUES(61, 'assert  ','vt. 维护，坚持   ' )";
    String VALUES62 ="VALUES(62, ' basement   ','n. 地下室；地窖    ' )";
    String VALUES63 ="VALUES(63, 'biologist  ','n. 生物学家   ' )";
    String VALUES64 ="VALUES(64, 'bounce  ','n. 跳；弹力   ' )";
    String VALUES65 ="VALUES(65, 'bulk  ','n. 体积，容量   ' )";
    String VALUES66 ="VALUES(66, 'canal  ',' n. 运河 vt. 在…开凿运河 ' )";
    String VALUES67 ="VALUES(67, ' category ',' n. 种类，[数] 范畴  ' )";
    String VALUES68 ="VALUES(68, ' converge   ',' vi. 聚合；集中于一点   ' )";
    String VALUES69 ="VALUES(69, 'craf  ','n. 工艺；太空船  ' )";
    String VALUES70 ="VALUES(70, 'deficient  ','adj. 不足的；有缺陷的   ' )";
    String VALUES71 ="VALUES(71, 'doctrine  ','n. 主义；学说；教义   ' )";
    String VALUES72 ="VALUES(72, ' embellish ','vt. 修饰；装饰；润色   ' )";
    String VALUES73 ="VALUES(73, ' exponent ','n. [数] 指数；典型   ' )";
    String VALUES74 ="VALUES(74, ' fascinate   ','vt. 使着迷，vi. 入迷    ' )";
    String VALUES75 ="VALUES(75, 'foremost  ','adj. 最重要的   ' )";
    String VALUES76 ="VALUES(76, 'gentle  ','n. 饵 adj. 温和的  ' )";
    String VALUES77 ="VALUES(77, 'herd  ',' n. 兽群，放牧人  ' )";
    String VALUES78 ="VALUES(78, 'hover  ',' n. 徘徊；盘旋  ' )";
    String VALUES79 ="VALUES(79, ' incessant ',' adj. 不断的；不停的  ' )";
    String VALUES80 ="VALUES(80, ' intact   ',' adj. 完整的   ' )";
    String VALUES81 ="VALUES(81, ' invariable ',' adj. 不变的；常数的  ' )";
    String VALUES82 ="VALUES(82, 'latitude  ','n. 纬度；界限   ' )";
    String VALUES83 ="VALUES(83, 'lichen  ',' n. 地衣；青苔  ' )";
    String VALUES84 ="VALUES(84, 'meteorologist  ',' n.气象学家  ' )";
    String VALUES85 ="VALUES(85, ' mobility ',' n. 移动性；机动性  ' )";
    String VALUES86 ="VALUES(86, ' moss   ',' vt. 使长满苔藓   ' )";
    String VALUES87 ="VALUES(87, 'overwhelm  ','vt. 压倒；淹没   ' )";
    String VALUES88 ="VALUES(88, 'perceive  ','vt. 察觉，感觉   ' )";
    String VALUES89 ="VALUES(89, 'plaza  ',' n. 广场；市场  ' )";
    String VALUES90 ="VALUES(90, ' regime ',' n. 政权，政体  ' )";
    String VALUES91 ="VALUES(91, 'sewerage  ','n.下水道，排水   ' )";
    String VALUES92 ="VALUES(92, 'sophisticated    ','adj. 复杂的；精致的    ' )";
    String VALUES93 ="VALUES(93, 'versatile  ',' adj. 多才多艺的；通用的  ' )";
    String VALUES94 ="VALUES(94, 'withstand  ','vt. 抵挡；禁得起   ' )";
    String VALUES95 ="VALUES(95, ' aquatic ','adj. 水生的；水栖的   ' )";
    String VALUES96 ="VALUES(96, 'bipedal  ',' adj.两足动物的；两足的  ' )";
    String VALUES97 ="VALUES(97, 'cranial  ','adj. 头盖的   ' )";
    String VALUES98 ="VALUES(98, ' dogged ','adj. 顽强的 vt. 跟踪  ' )";
    String VALUES99 ="VALUES(99, 'deteriorate  ','vi. 恶化，变坏   ' )";
    String VALUES100 ="VALUES(100, 'maize  ','adj. 黄色的，玉米色的   ' )";
    String VALUES101 ="VALUES(101, 'evaporate  ','vt. 使……蒸发   ' )";
    String VALUES102="VALUES(102, 'forge  ','n. 熔炉，锻铁炉   ' )";
    String VALUES103 ="VALUES(103, 'inclination  ','n. 倾向，爱好   ' )";
    String VALUES104 ="VALUES(104, 'invertebrate  ','adj. 无脊椎的；无骨气的   ' )";
    String VALUES105 ="VALUES(105, 'jumble  ','n. 混乱；杂乱的   ' )";
    String VALUES106 ="VALUES(106, 'dismay  ','n. 沮丧，灰心   ' )";
    //build databse
    public DBHelper(Context context) {
        super(context, "word_2ed.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //build table
        db.execSQL("DROP TABLE IF EXISTS wordtable");
        db.execSQL(CREATE_TABLE);
//        db.execSQL(INSERT_DATA+VALUES1);
//        db.execSQL(INSERT_DATA+VALUES2);
//        db.execSQL(INSERT_DATA+VALUES3);
//        db.execSQL(INSERT_DATA+VALUES4);
//        db.execSQL(INSERT_DATA+VALUES5);
//        db.execSQL(INSERT_DATA+VALUES6);
//        db.execSQL(INSERT_DATA+VALUES7);
//        db.execSQL(INSERT_DATA+VALUES8);
//        db.execSQL(INSERT_DATA+VALUES9);
//        db.execSQL(INSERT_DATA+VALUES10);
//        db.execSQL(INSERT_DATA+VALUES11);
//        db.execSQL(INSERT_DATA+VALUES12);
        db.execSQL(INSERT_DATA+VALUES1);
        db.execSQL(INSERT_DATA+VALUES2);
        db.execSQL(INSERT_DATA+VALUES3);
        db.execSQL(INSERT_DATA+VALUES4);
        db.execSQL(INSERT_DATA+VALUES5);
        db.execSQL(INSERT_DATA+VALUES6);
        db.execSQL(INSERT_DATA+VALUES7);
        db.execSQL(INSERT_DATA+VALUES8);
        db.execSQL(INSERT_DATA+VALUES9);
        db.execSQL(INSERT_DATA+VALUES10);
        db.execSQL(INSERT_DATA+VALUES11);
        db.execSQL(INSERT_DATA+VALUES12);
        db.execSQL(INSERT_DATA+VALUES13);
        db.execSQL(INSERT_DATA+VALUES14);
        db.execSQL(INSERT_DATA+VALUES15);
        db.execSQL(INSERT_DATA+VALUES16);
        db.execSQL(INSERT_DATA+VALUES17);
        db.execSQL(INSERT_DATA+VALUES18);
        db.execSQL(INSERT_DATA+VALUES19);
        db.execSQL(INSERT_DATA+VALUES20);
        db.execSQL(INSERT_DATA+VALUES21);
        db.execSQL(INSERT_DATA+VALUES22);
        db.execSQL(INSERT_DATA+VALUES23);
        db.execSQL(INSERT_DATA+VALUES24);
        db.execSQL(INSERT_DATA+VALUES25);
        db.execSQL(INSERT_DATA+VALUES26);
        db.execSQL(INSERT_DATA+VALUES27);
        db.execSQL(INSERT_DATA+VALUES28);
        db.execSQL(INSERT_DATA+VALUES29);
        db.execSQL(INSERT_DATA+VALUES30);
        db.execSQL(INSERT_DATA+VALUES31);
        db.execSQL(INSERT_DATA+VALUES32);
        db.execSQL(INSERT_DATA+VALUES33);
        db.execSQL(INSERT_DATA+VALUES34);
        db.execSQL(INSERT_DATA+VALUES35);
        db.execSQL(INSERT_DATA+VALUES36);
        db.execSQL(INSERT_DATA+VALUES37);
        db.execSQL(INSERT_DATA+VALUES38);
        db.execSQL(INSERT_DATA+VALUES39);
        db.execSQL(INSERT_DATA+VALUES40);
        db.execSQL(INSERT_DATA+VALUES41);
        db.execSQL(INSERT_DATA+VALUES42);
        db.execSQL(INSERT_DATA+VALUES43);
        db.execSQL(INSERT_DATA+VALUES44);
        db.execSQL(INSERT_DATA+VALUES45);
        db.execSQL(INSERT_DATA+VALUES46);
        db.execSQL(INSERT_DATA+VALUES47);
        db.execSQL(INSERT_DATA+VALUES48);
        db.execSQL(INSERT_DATA+VALUES49);
        db.execSQL(INSERT_DATA+VALUES50);
        db.execSQL(INSERT_DATA+VALUES51);
        db.execSQL(INSERT_DATA+VALUES52);
        db.execSQL(INSERT_DATA+VALUES53);
        db.execSQL(INSERT_DATA+VALUES54);
        db.execSQL(INSERT_DATA+VALUES55);
        db.execSQL(INSERT_DATA+VALUES56);
        db.execSQL(INSERT_DATA+VALUES57);
        db.execSQL(INSERT_DATA+VALUES58);
        db.execSQL(INSERT_DATA+VALUES59);
        db.execSQL(INSERT_DATA+VALUES60);
        db.execSQL(INSERT_DATA+VALUES61);
        db.execSQL(INSERT_DATA+VALUES62);
        db.execSQL(INSERT_DATA+VALUES63);
        db.execSQL(INSERT_DATA+VALUES64);
        db.execSQL(INSERT_DATA+VALUES65);
        db.execSQL(INSERT_DATA+VALUES66);
        db.execSQL(INSERT_DATA+VALUES67);
        db.execSQL(INSERT_DATA+VALUES68);
        db.execSQL(INSERT_DATA+VALUES69);
        db.execSQL(INSERT_DATA+VALUES70);
        db.execSQL(INSERT_DATA+VALUES71);
        db.execSQL(INSERT_DATA+VALUES72);
        db.execSQL(INSERT_DATA+VALUES73);
        db.execSQL(INSERT_DATA+VALUES74);
        db.execSQL(INSERT_DATA+VALUES75);
        db.execSQL(INSERT_DATA+VALUES76);
        db.execSQL(INSERT_DATA+VALUES77);
        db.execSQL(INSERT_DATA+VALUES78);
        db.execSQL(INSERT_DATA+VALUES79);
        db.execSQL(INSERT_DATA+VALUES80);
        db.execSQL(INSERT_DATA+VALUES81);
        db.execSQL(INSERT_DATA+VALUES82);
        db.execSQL(INSERT_DATA+VALUES83);
        db.execSQL(INSERT_DATA+VALUES84);
        db.execSQL(INSERT_DATA+VALUES85);
        db.execSQL(INSERT_DATA+VALUES86);
        db.execSQL(INSERT_DATA+VALUES87);
        db.execSQL(INSERT_DATA+VALUES88);
        db.execSQL(INSERT_DATA+VALUES89);
        db.execSQL(INSERT_DATA+VALUES90);
        db.execSQL(INSERT_DATA+VALUES91);
        db.execSQL(INSERT_DATA+VALUES92);
        db.execSQL(INSERT_DATA+VALUES93);
        db.execSQL(INSERT_DATA+VALUES94);
        db.execSQL(INSERT_DATA+VALUES95);
        db.execSQL(INSERT_DATA+VALUES96);
        db.execSQL(INSERT_DATA+VALUES97);
        db.execSQL(INSERT_DATA+VALUES98);
        db.execSQL(INSERT_DATA+VALUES99);
        db.execSQL(INSERT_DATA+VALUES100);
        db.execSQL(INSERT_DATA+VALUES101);
        db.execSQL(INSERT_DATA+VALUES102);
        db.execSQL(INSERT_DATA+VALUES103);
        db.execSQL(INSERT_DATA+VALUES104);
        db.execSQL(INSERT_DATA+VALUES105);
        db.execSQL(INSERT_DATA+VALUES106);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        System.out.print("DB UPGRADED");

    }
}

