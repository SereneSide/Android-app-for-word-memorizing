package com.proj.wordmemorizing;

//单词属性
public class word {

    private boolean isSelected;
    private int id;
    private String en_word;
    private String meaning;

    public void setEn_word(String en_word) {
        this.en_word = en_word;

    }


    public String getEn_word() {
        return en_word;
    }



    public word(int id, String en_word, String meaning) {
        this.id = id;
        this.en_word = en_word;
        this.meaning = meaning;
    }

    public String toStringWord() { return en_word;}

    public String toStringMeaning() {
        return meaning;
    }

//    public word toString(word w){
//        return w;
//    }

    public boolean getSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}

